"""Tests for main.py CLI functions."""

import json
import sys
import types
from pathlib import Path

import pytest

import main
from config import CharacterMapping, PipelineConfig


# ---------------------------------------------------------------------------
# _scan_image_dir
# ---------------------------------------------------------------------------

class TestScanImageDir:
    def test_valid_dir_with_images(self, tmp_path):
        for name in ("a.jpg", "b.png", "c.bmp"):
            (tmp_path / name).touch()
        paths = main._scan_image_dir(str(tmp_path), "find")
        assert len(paths) == 3
        assert all(p.endswith((".jpg", ".png", ".bmp")) for p in paths)

    def test_non_image_files_excluded(self, tmp_path):
        (tmp_path / "a.jpg").touch()
        (tmp_path / "readme.txt").touch()
        paths = main._scan_image_dir(str(tmp_path), "find")
        assert len(paths) == 1

    def test_empty_dir_exits(self, tmp_path):
        with pytest.raises(SystemExit):
            main._scan_image_dir(str(tmp_path), "find")

    def test_non_existent_dir_exits(self):
        with pytest.raises(SystemExit):
            main._scan_image_dir("/no/such/dir", "find")

    def test_returns_sorted_paths(self, tmp_path):
        for name in ("z.jpg", "a.jpg", "m.jpg"):
            (tmp_path / name).touch()
        paths = main._scan_image_dir(str(tmp_path), "find")
        assert paths == sorted(paths)


# ---------------------------------------------------------------------------
# _build_config_from_args
# ---------------------------------------------------------------------------

class TestBuildConfigFromArgs:
    def _make_args(self, tmp_path, **kw):
        find_dir = tmp_path / "find"
        find_dir.mkdir()
        (find_dir / "face.jpg").touch()
        replace_dir = tmp_path / "replace"
        replace_dir.mkdir()
        (replace_dir / "portrait.jpg").touch()

        ns = types.SimpleNamespace(
            input_video=str(tmp_path / "in.mp4"),
            output_video=str(tmp_path / "out.mp4"),
            characters=[[str(find_dir), str(replace_dir)]],
            similarity_threshold=0.5,
            detection_model="buffalo_l",
            detect_size=640,
            swap_model_path=None,
            embedding_converter_path=None,
            enhance=False,
            enhance_model="gfpgan",
            enhance_model_path=None,
            enhance_weight=0.7,
            device=0,
            no_fp16=False,
            codec="libx264",
            crf=18,
            no_audio=False,
            blend_mode="seamless",
            mask_blur_kernel=15,
            mask_erode_pixels=5,
            verbose=False,
            log_file=None,
            timers=False,
            dump_config=False,
        )
        for k, v in kw.items():
            setattr(ns, k, v)
        return ns

    def test_basic_config(self, tmp_path):
        args = self._make_args(tmp_path)
        cfg = main._build_config_from_args(args)
        assert isinstance(cfg, PipelineConfig)
        assert len(cfg.characters) == 1
        assert cfg.characters[0].source_label == "find"

    def test_enhance_flag_enabled(self, tmp_path):
        args = self._make_args(tmp_path, enhance=True)
        cfg = main._build_config_from_args(args)
        assert cfg.enable_face_enhancement is True

    def test_enhance_flag_disabled(self, tmp_path):
        args = self._make_args(tmp_path)
        cfg = main._build_config_from_args(args)
        assert cfg.enable_face_enhancement is False
    def test_verbose_sets_debug(self, tmp_path):
        args = self._make_args(tmp_path, verbose=True)
        cfg = main._build_config_from_args(args)
        assert cfg.log_level == "DEBUG"

    def test_no_audio_flag(self, tmp_path):
        args = self._make_args(tmp_path, no_audio=True)
        cfg = main._build_config_from_args(args)
        assert cfg.copy_audio is False

    def test_no_fp16_flag(self, tmp_path):
        args = self._make_args(tmp_path, no_fp16=True)
        cfg = main._build_config_from_args(args)
        assert cfg.use_fp16 is False


# ---------------------------------------------------------------------------
# _build_config_from_json
# ---------------------------------------------------------------------------

class TestBuildConfigFromJson:
    def test_load_with_find_replace_folders(self, tmp_path):
        find_dir = tmp_path / "originals" / "villain"
        find_dir.mkdir(parents=True)
        (find_dir / "ref.jpg").touch()
        replace_dir = tmp_path / "replacements" / "villain"
        replace_dir.mkdir(parents=True)
        (replace_dir / "portrait.jpg").touch()

        video = tmp_path / "in.mp4"
        video.touch()

        config_data = {
            "input_video": str(video),
            "output_video": "out.mp4",
            "characters": [
                {
                    "find": str(find_dir),
                    "replace": str(replace_dir),
                    "similarity_threshold": 0.6,
                }
            ],
        }
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config_data))

        cfg = main._build_config_from_json(str(config_file))
        assert isinstance(cfg, PipelineConfig)
        assert len(cfg.characters) == 1
        assert cfg.characters[0].source_label == "villain"
        assert cfg.characters[0].similarity_threshold == 0.6

    def test_load_with_explicit_paths(self, tmp_path):
        ref = tmp_path / "ref.jpg"
        ref.touch()
        portrait = tmp_path / "portrait.jpg"
        portrait.touch()

        config_data = {
            "input_video": "",
            "output_video": "out.mp4",
            "characters": [
                {
                    "source_label": "hero",
                    "reference_paths": [str(ref)],
                    "portrait_paths": [str(portrait)],
                }
            ],
        }
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config_data))

        cfg = main._build_config_from_json(str(config_file))
        assert cfg.characters[0].source_label == "hero"

    def test_label_key_remapped(self, tmp_path):
        find_dir = tmp_path / "find"
        find_dir.mkdir()
        (find_dir / "f.jpg").touch()
        replace_dir = tmp_path / "replace"
        replace_dir.mkdir()
        (replace_dir / "r.jpg").touch()

        config_data = {
            "input_video": "",
            "output_video": "out.mp4",
            "characters": [
                {
                    "find": str(find_dir),
                    "replace": str(replace_dir),
                    "label": "custom_label",
                }
            ],
        }
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config_data))

        cfg = main._build_config_from_json(str(config_file))
        assert cfg.characters[0].source_label == "custom_label"


# ---------------------------------------------------------------------------
# _setup_logging (smoke test)
# ---------------------------------------------------------------------------

class TestSetupLogging:
    def test_no_raise(self):
        cfg = PipelineConfig(log_level="DEBUG", log_file=None)
        main._setup_logging(cfg)

    def test_with_log_file(self, tmp_path):
        log_file = str(tmp_path / "test.log")
        cfg = PipelineConfig(log_level="INFO", log_file=log_file)
        main._setup_logging(cfg)
        assert Path(log_file).exists()


# ---------------------------------------------------------------------------
# _parse_args (smoke test)
# ---------------------------------------------------------------------------

class TestParseArgs:
    def test_defaults(self, monkeypatch):
        monkeypatch.setattr(sys, "argv", ["chararep"])
        args = main._parse_args()
        assert args.input_video is None
        assert args.output_video is None
        assert args.blend_mode == "alpha"
        assert args.crf == 18

    def test_verbose_flag(self, monkeypatch):
        monkeypatch.setattr(sys, "argv", ["chararep", "-v"])
        args = main._parse_args()
        assert args.verbose is True

    def test_timers_default_false(self, monkeypatch):
        monkeypatch.setattr(sys, "argv", ["chararep"])
        args = main._parse_args()
        assert args.timers is False

    def test_timers_flag(self, monkeypatch):
        monkeypatch.setattr(sys, "argv", ["chararep", "--timers"])
        args = main._parse_args()
        assert args.timers is True


class TestTimersConfig:
    def _make_args(self, tmp_path, **kw):
        find_dir = tmp_path / "find"
        find_dir.mkdir()
        (find_dir / "face.jpg").touch()
        replace_dir = tmp_path / "replace"
        replace_dir.mkdir()
        (replace_dir / "portrait.jpg").touch()

        ns = types.SimpleNamespace(
            input_video=str(tmp_path / "in.mp4"),
            output_video=str(tmp_path / "out.mp4"),
            characters=[[str(find_dir), str(replace_dir)]],
            similarity_threshold=0.5,
            detection_model="buffalo_l",
            detect_size=640,
            swap_model_path=None,
            embedding_converter_path=None,
            enhance=False,
            enhance_model="gfpgan",
            enhance_model_path=None,
            enhance_weight=0.7,
            device=0,
            no_fp16=False,
            codec="libx264",
            crf=18,
            no_audio=False,
            blend_mode="seamless",
            mask_blur_kernel=15,
            mask_erode_pixels=5,
            verbose=False,
            log_file=None,
            timers=False,
            dump_config=False,
        )
        for k, v in kw.items():
            setattr(ns, k, v)
        return ns

    def test_timers_disabled_by_default(self, tmp_path):
        args = self._make_args(tmp_path)
        cfg = main._build_config_from_args(args)
        assert cfg.enable_timers is False

    def test_timers_enabled_by_flag(self, tmp_path):
        args = self._make_args(tmp_path, timers=True)
        cfg = main._build_config_from_args(args)
        assert cfg.enable_timers is True
