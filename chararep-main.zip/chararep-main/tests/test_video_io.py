"""Tests for video_io.py."""

import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock

import numpy as np
import pytest

from video_io import VideoReader, VideoWriter


# ---------------------------------------------------------------------------
# VideoReader tests
# ---------------------------------------------------------------------------

class TestVideoReader:
    def _make_reader(self, frames=None, monkeypatch=None):
        """Return a VideoReader backed by a mock VideoCapture."""
        if frames is None:
            frames = [np.zeros((48, 64, 3), dtype=np.uint8)]

        frame_iter = iter([(True, f) for f in frames] + [(False, None)])

        mock_cap = MagicMock()
        mock_cap.isOpened.return_value = True
        mock_cap.read.side_effect = lambda: next(frame_iter)
        mock_cap.get.side_effect = lambda prop: {
            3: 64.0,   # width
            4: 48.0,   # height
            5: 25.0,   # fps
            7: len(frames),  # total frames
        }.get(prop, 0.0)

        import cv2
        with patch.object(cv2, "VideoCapture", return_value=mock_cap):
            reader = VideoReader.__new__(VideoReader)
            VideoReader.__init__(reader, "fake.mp4")

        reader._cap = mock_cap
        return reader

    def test_init_attributes(self, monkeypatch):
        frames = [np.zeros((48, 64, 3), dtype=np.uint8)] * 3
        reader = self._make_reader(frames)
        assert reader.width == 64
        assert reader.height == 48
        assert reader.fps == 25.0
        assert reader.total_frames == 3

    def test_start_and_read_frames(self):
        frame = np.full((48, 64, 3), 42, dtype=np.uint8)
        reader = self._make_reader([frame])
        reader.start()
        got = reader.read(timeout=2.0)
        reader.stop()
        assert got is not None
        np.testing.assert_array_equal(got, frame)

    def test_read_returns_none_at_end_of_stream(self):
        reader = self._make_reader([np.zeros((48, 64, 3), dtype=np.uint8)])
        reader.start()
        reader.read(timeout=2.0)   # the real frame
        result = reader.read(timeout=2.0)  # EOS
        reader.stop()
        assert result is None

    def test_context_manager(self):
        reader = self._make_reader([np.zeros((48, 64, 3), dtype=np.uint8)])
        with reader as r:
            frame = r.read(timeout=2.0)
        assert frame is not None

    def test_iter(self):
        frames = [np.full((48, 64, 3), i, dtype=np.uint8) for i in range(3)]
        reader = self._make_reader(frames)
        reader.start()
        collected = list(reader)
        reader.stop()
        assert len(collected) == 3

    def test_stop_event_fires(self):
        """stop() sets the event so the decode loop can exit cleanly."""
        frame = np.zeros((48, 64, 3), dtype=np.uint8)
        reader = self._make_reader([frame] * 100)
        reader.start()
        time.sleep(0.05)
        reader.stop()
        assert reader._stop_event.is_set()

    def test_cannot_open_raises(self):
        import cv2
        mock_cap = MagicMock()
        mock_cap.isOpened.return_value = False
        with patch.object(cv2, "VideoCapture", return_value=mock_cap):
            with pytest.raises(FileNotFoundError):
                VideoReader("nonexistent.mp4")


# ---------------------------------------------------------------------------
# VideoWriter tests
# ---------------------------------------------------------------------------

class TestVideoWriter:
    def _make_writer(self, tmp_path, width=64, height=48, fps=25.0):
        out = str(tmp_path / "out.mp4")
        mock_proc = MagicMock()
        mock_proc.stdin = MagicMock()
        mock_proc.stdin.write = MagicMock()
        mock_proc.stdin.close = MagicMock()
        mock_proc.wait = MagicMock(return_value=0)

        with patch("subprocess.Popen", return_value=mock_proc):
            writer = VideoWriter(out, width, height, fps)
            writer.start()

        return writer, mock_proc

    def test_write_and_stop(self, tmp_path):
        writer, mock_proc = self._make_writer(tmp_path)
        frame = np.zeros((48, 64, 3), dtype=np.uint8)
        writer.write(frame)
        writer.stop()
        # stdin.write should have been called with frame bytes
        mock_proc.stdin.write.assert_called()

    def test_context_manager(self, tmp_path):
        out = str(tmp_path / "out.mp4")
        mock_proc = MagicMock()
        mock_proc.stdin = MagicMock()
        mock_proc.wait = MagicMock(return_value=0)

        with patch("subprocess.Popen", return_value=mock_proc):
            with VideoWriter(out, 64, 48, 25.0) as writer:
                frame = np.zeros((48, 64, 3), dtype=np.uint8)
                writer.write(frame)

        mock_proc.stdin.write.assert_called()

    def test_broken_pipe_handled(self, tmp_path):
        """BrokenPipeError during write doesn't propagate."""
        writer, mock_proc = self._make_writer(tmp_path)
        mock_proc.stdin.write.side_effect = BrokenPipeError
        frame = np.zeros((48, 64, 3), dtype=np.uint8)
        writer.write(frame)
        writer.stop()  # should not raise

    def test_stop_with_timeout_expired(self, tmp_path):
        """TimeoutExpired on proc.wait → terminate() called."""
        import subprocess
        writer, mock_proc = self._make_writer(tmp_path)
        mock_proc.wait.side_effect = [subprocess.TimeoutExpired(cmd="ffmpeg", timeout=120), 0]
        writer.stop()
        mock_proc.terminate.assert_called()

    def test_stdin_close_oserror_handled(self, tmp_path):
        """OSError on stdin.close is silently swallowed."""
        writer, mock_proc = self._make_writer(tmp_path)
        mock_proc.stdin.close.side_effect = OSError
        writer.stop()  # must not raise

    def test_mux_audio_called_when_audio_source_set(self, tmp_path):
        """When audio_source is given, _mux_audio is invoked after stop."""
        out = str(tmp_path / "out.mp4")
        mock_proc = MagicMock()
        mock_proc.stdin = MagicMock()
        mock_proc.wait = MagicMock(return_value=0)

        src = str(tmp_path / "src.mp4")
        Path(src).touch()

        mux_mock = MagicMock()
        with patch("subprocess.Popen", return_value=mock_proc):
            writer = VideoWriter(out, 64, 48, 25.0, audio_source=src)
            writer._mux_audio = mux_mock
            writer.start()
            writer.stop()

        # _mux_audio should have been called IF the tmp file exists;
        # since there is no real ffmpeg we just verify the writer started.
        assert writer.path == out
