"""Tests for pipeline --timers functionality."""

import logging

import pytest

from config import PipelineConfig
from pipeline import CharacterReplacementPipeline


# ---------------------------------------------------------------------------
# _log_timer_distribution (unit test – no GPU required)
# ---------------------------------------------------------------------------

class TestLogTimerDistribution:
    def test_logs_all_stages(self, caplog):
        timers = {
            "detect": 1.0,
            "recognize": 0.5,
            "swap": 2.0,
            "enhance": 0.3,
            "blend": 0.2,
        }
        with caplog.at_level(logging.INFO, logger="pipeline"):
            CharacterReplacementPipeline._log_timer_distribution(timers)

        text = caplog.text
        for stage in ("detect", "recognize", "swap", "enhance", "blend", "TOTAL"):
            assert stage in text

    def test_percentages_sum_to_100(self, caplog):
        timers = {
            "detect": 1.0,
            "recognize": 1.0,
            "swap": 1.0,
            "enhance": 1.0,
            "blend": 1.0,
        }
        # Each stage is 20% of total (5 stages × 1.0 s = 5.0 s total)
        with caplog.at_level(logging.INFO, logger="pipeline"):
            CharacterReplacementPipeline._log_timer_distribution(timers)

        assert "20.0%" in caplog.text

    def test_total_shown(self, caplog):
        timers = {"detect": 2.0, "recognize": 3.0, "swap": 5.0, "enhance": 0.0, "blend": 0.0}
        with caplog.at_level(logging.INFO, logger="pipeline"):
            CharacterReplacementPipeline._log_timer_distribution(timers)

        assert "TOTAL" in caplog.text
        assert "10.000 s" in caplog.text

    def test_zero_total_does_not_raise(self, caplog):
        timers = {"detect": 0.0, "recognize": 0.0, "swap": 0.0, "enhance": 0.0, "blend": 0.0}
        with caplog.at_level(logging.INFO, logger="pipeline"):
            CharacterReplacementPipeline._log_timer_distribution(timers)

        assert "TOTAL" in caplog.text


# ---------------------------------------------------------------------------
# PipelineConfig.enable_timers default
# ---------------------------------------------------------------------------

class TestPipelineConfigTimers:
    def test_default_is_false(self):
        cfg = PipelineConfig()
        assert cfg.enable_timers is False

    def test_can_be_enabled(self):
        cfg = PipelineConfig(enable_timers=True)
        assert cfg.enable_timers is True
